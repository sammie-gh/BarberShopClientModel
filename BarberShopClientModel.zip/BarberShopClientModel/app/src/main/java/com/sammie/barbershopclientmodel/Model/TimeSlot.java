package com.sammie.barbershopclientmodel.Model;

public class TimeSlot {
    private Long slot;

    public TimeSlot() {
    }

    public Long getSlot() {
        return slot;
    }

    public void setSlot(Long slot) {
        this.slot = slot;
    }
}
