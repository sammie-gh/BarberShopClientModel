package com.sammie.barbershopclientmodel.Interface;

public interface ICartItemUpdateListener {
    void onCartItemUpdateSuccess ();

}
