package com.sammie.barbershopclientmodel.Interface;

public interface ISumListener {
    void onSumCartSuccess(Long value);
}
