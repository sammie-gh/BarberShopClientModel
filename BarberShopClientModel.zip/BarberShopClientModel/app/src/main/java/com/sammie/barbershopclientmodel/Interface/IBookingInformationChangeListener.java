package com.sammie.barbershopclientmodel.Interface;

public interface IBookingInformationChangeListener {
    void onBookingInformationChange();
}
