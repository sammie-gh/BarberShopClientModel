package com.sammie.barbershopclientmodel.Interface;

public interface ICountItemCartListener {

    void onCartItemCountSuccess(int count);
}
