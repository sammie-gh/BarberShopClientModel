# BarberShopClientModel
 Barbe rmodels
